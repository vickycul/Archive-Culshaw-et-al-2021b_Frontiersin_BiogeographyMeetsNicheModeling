## 
## Title: A Biogeographic and Ecological niche partnership to reconstruct the role of deep-time climate change when data is limited
## 
## V Culshaw
## M Mairal
## I Sanmartin
## 
## Frontier: Ecology and Evolution.
## 
## First published XXX
##

library(lattice)

# General settings for plots:
trellis.par.get("fontsize") -> fontsize
fontsize$default<-34
fontsize$points<-22
fontsize$text<-34
op <- par()

# env=rsaga.env(cmd  = "saga_cmd", path = "/usr/local/bin", modules = "/usr/local/lib/saga", version = "2.3.0", os.default.path = "/usr/local/bin")
env=rsaga.env(cmd  = "saga_cmd", path = "/usr/local/bin", modules = "/usr/local/lib/saga", version = "2.3.0", root = "/usr/local/bin")

rotate_vmvc <- function(x) t(apply(x, 2, rev)) # rotate vector

rsaga.geoprocessor_vmvc<-function (env = rsaga.env(), lib, module = NULL, param = list(), show.output.on.console = TRUE, 
                                   invisible = TRUE, intern = TRUE, prefix = NULL, flags = ifelse(show.output.on.console,"q", "s"), cores, display.command = T, 
                                   reduce.intern = TRUE, check.module.exists = TRUE, warn = options("warn")$warn, 
                                   argsep = " ", ...) {
  if (!missing(cores)) env$cores = cores
  if (!is.na(env$cores) & (substr(env$version, 1, 4) == "2.0.")) {
    warning("'cores' argument not supported by SAGA GIS versions <2.1.0; ignoring 'cores' argument\n", 
            "Use SAGA GIS 2.1.0+ for multicore geoprocessing.")
    env$cores = NA
  }
  if (is.na(env$version) | (substr(env$version, 1, 4) == "2.0.")) {
    if (argsep != " ") 
      warning("To my knowledge, SAGA GIS 2.0.x only supports argsep=' '.\nUse different argsep values at own risk.")
  } else {
    if (!(argsep %in% c(" ", "="))) 
      warning("To my knowledge, SAGA GIS only supports argsep=' ' or (partially also) '='.\nUse different argsep values at own risk.")
  }
  old.wd = getwd()
  on.exit(setwd(old.wd))
  setwd(env$workspace) # !!!! maybe I am wrong here
  if ((Sys.info()["sysname"] != "Windows") | is.na(env$version) | (env$version == "2.0.4")) {
    old.saga = Sys.getenv("SAGA", unset = NA)
    old.saga.mlb = Sys.getenv("SAGA_MLB", unset = NA)
    on.exit(if (is.na(old.saga)) Sys.unsetenv("SAGA") else Sys.setenv(SAGA = old.saga), 
            add = TRUE)
    on.exit(if (is.na(old.saga.mlb)) Sys.unsetenv("SAGA_MLB") else Sys.setenv(SAGA_MLB = old.saga.mlb), 
            add = TRUE)
    Sys.setenv(SAGA = env$path, SAGA_MLB = env$modules)
  }
  command = shQuote(paste(env$path, .Platform$file.sep, env$cmd, sep = ""))
  
  if (!is.null(prefix)) command = paste(command, prefix, sep = " ")
  if (!(env$version %in% c("2.0.4", "2.0.5", "2.0.6", "2.0.7", "2.0.8", "2.0.9"))) {
    if (!is.null(flags)) 
      command = paste(command, " -f=", flags, sep = "")
    if (!is.null(lib) & !is.null(module) & (length(param) > 0)) {
      if (!is.na(env$cores)) {
        command = paste(command, " --cores=", env$cores, sep = "")
      }
    }
  }
  if (!is.null(lib)) {
    if (is.null(env$lib.prefix) | !(env$version %in% c("2.0.4", "2.0.5", "2.0.6", "2.0.7", "2.0.8", "2.0.9"))) 
      env$lib.prefix = ""
    command = paste(command, " ", env$lib.prefix, lib, sep = "")
  }
  # if (!is.null(lib) & !is.null(module)) {
  #   if (check.module.exists) {
  #     ex = rsaga.module.exists(lib, module, env = env)
  #     if (!ex) {
  #       cat("Module '", module, "' not found in SAGA library '", 
  #           lib, "'.\n", "Check if module name has changed (or is misspelled)?\n", 
  #           sep = "")
  #       cat("The following (non-interactive) modules currently exist in this SAGA library:\n\n")
  #       print(rsaga.get.modules(lib, env = env, interactive = FALSE))
  #       cat("\n")
  #       stopifnot(rsaga.module.exists(lib, module, env = env))
  #     }
  #   }
  if (is.character(module)) 
    module = shQuote(module)
  command = paste(command, module)
  if (length(param) > 0) {
    if (!(env$version %in% c("2.0.4", "2.0.5", "2.0.6", 
                             "2.0.7", "2.0.8", "2.0.9", "2.1.0", "2.1.1", 
                             "2.1.2"))) {
      i = 1
      while (i <= length(param)) {
        if (is.logical(param[[i]])) {
          if (!param[[i]]) {
            param[[i]] = "false"
            i = i - 1
          } else {param[[i]] = "true"}
        }
        i = i + 1
      }
    } else {
      i = 1
      while (i <= length(param)) {
        if (is.logical(param[[i]])) {
          if (!param[[i]]) {
            param[[i]] = NULL
            i = i - 1
          } else {param[[i]] = ""}
        }
        i = i + 1
      }
    }
    nm = names(param)
    val = as.character(unlist(param))
    val[nchar(val) > 0] = shQuote(val[nchar(val) > 0])
    param = paste("-", nm, argsep, val, sep = "", collapse = " ")
    command = paste(command, param)
  }
  # }
  if (display.command) cat(command, "\n")
  if (Sys.info()["sysname"] == "Windows") {
    oldwarn = options("warn")$warn
    on.exit(options(warn = oldwarn), add = TRUE)
    options(warn = warn)
    res = system(command, intern = intern, show.output.on.console = show.output.on.console, invisible = invisible)   # !!!! run here
    options(warn = oldwarn)
  } else {
    oldwarn = options("warn")$warn
    on.exit(options(warn = oldwarn), add = TRUE)
    options(warn = warn)
    res = system(command, intern = intern)
    options(warn = oldwarn)
  }
  
  # Export SAGA_MLB='/usr/local/lib/saga'
  
  if (intern) {
    if (reduce.intern) {
      remove = grep("\r", res, fixed = TRUE)
      if (length(remove) > 0) 
        res = res[-remove]
      remove = grep("^.*##.*##", res)
      if (length(remove) > 0) 
        res = res[-remove]
      if (any(remove <- res == "go...")) 
        res = res[!remove]
      if (any(remove <- res == "okay")) 
        res = res[!remove]
      if (any(remove <- substr(res, 1, 7) == "type -h")) 
        res = res[!remove]
      if (any(remove <- substr(res, 1, 7) == "_______")) 
        res = res[!remove]
    }
    if (show.output.on.console) 
      cat(res, sep = "\n")
  }
  if (intern) {
    invisible(res)
  } else {return(res)}
}

rsaga.sgrd.to.esri_vmvc <- function (in.sgrds, out.grids, out.path, format = "ascii", georef = "corner", env = rsaga.env(), prec = 5){
  in.sgrds = default.file.extension(in.sgrds, ".sgrd")
  format = match.arg.ext(format, choices = c("binary", "ascii"), 
                         base = 0, ignore.case = TRUE, numeric = TRUE)
  georef = match.arg.ext(georef, choices = c("corner", "center"), 
                         base = 0, ignore.case = TRUE, numeric = TRUE)
  if (missing(out.grids)) 
    out.grids = set.file.extension(in.sgrds, c(".flt", ".asc")[format + 1])
  out.grids = default.file.extension(out.grids, c(".flt", ".asc")[format + 1])
  if (!missing(out.path)) 
    out.grids = file.path(out.path, out.grids)
  if (length(out.grids) != length(in.sgrds)) 
    stop("must have the same number of input and outpute grids")
  if ((length(prec) == 1) & (length(in.sgrds) > 1)) 
    prec = rep(prec, length(in.sgrds))
  if (length(prec) != length(in.sgrds)) 
    stop("must have same number of in-/output grids and 'prec' parameters (or length(prec)==1)")
  res = c()
  for (i in 1:length(in.sgrds)) 
    res = c(res, rsaga.geoprocessor_vmvc(env=env, "io_grid", "Export ESRI Arc/Info Grid", 
                                         list(GRID = in.sgrds[i], FILE = out.grids[i],
                                              FORMAT = format, GEOREF = georef,
                                              PREC = prec[i]))
            )
  invisible(res)
}

join_vmvc <- function(xy, x){
  ## Verifications
  if (is(x, "SpatialGrid"))
    fullgrid(x) = FALSE
  if (!inherits(x, "SpatialPixelsDataFrame")) stop("non convenient data")
  if (!inherits(xy, "SpatialPoints")) stop("non convenient data")
  gr <- gridparameters(x)
  if (nrow(gr) > 2)
    stop("x should be defined in two dimensions")
  if ((gr[1, 2] - gr[2, 2])> get(".adeoptions", envir=.adehabitatMAEnv)$epsilon)
    stop("the cellsize should be the same in x and y directions")
  if (ncol(coordinates(xy))>2)
    stop("xy should be defined in two dimensions")
  pfsx <- proj4string(x)
  pfsxy <- proj4string(xy)
  if (!identical(pfsx, pfsxy))
    stop("different proj4string in x and xy")
  
  ## output
  sorties <- as.data.frame(x)[over(xy, geometry(x)),]
  
  sorties<-sorties[,-c(ncol(as.data.frame(x))-1,ncol(as.data.frame(x)))]
  if (inherits(sorties, "data.frame"))
    names(sorties)<-names(as.data.frame(x)[-c(ncol(as.data.frame(x))-1,ncol(as.data.frame(x)))])
  return(sorties)
}

# =======================
# =======================
### END.
##
#
