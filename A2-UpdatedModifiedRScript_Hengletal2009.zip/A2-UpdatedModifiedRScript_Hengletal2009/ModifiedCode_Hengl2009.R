## 
## Title: Biogeography Meets Niche Modeling: Inferring the Role of Deep Time Climate Change When Data Is Limited
## 
## V Culshaw
## M Mairal
## I Sanmartin
## 
## Frontier: Ecology and Evolution.
## 
## doi: 10.3389/fevo.2021.662092 
## First published 2021
##
## original script available at spatialanalyst.net /wiki/ index.php/ Species_Distribution_Modelling downloaded in 2015. I have only added the section to project the model
## over new data. These lines are highlighted with the comment "!!!! This is where I need to add the new data to predict backwards."
## You should check with Hengl et al. 2009 whether there is an updated script.
## Note 1, you require to install the command line version of SAGA to use the RSAGE package. https://sourceforge.net/projects/saga-gis/
## Note 2, you require to install the dated package "adehabitat_1.8.18_DONT-DELETE.tar.gz". I have included it within the appendix 2.
##

library(raster)
library(adehabitatHS)
library(adehabitat) # Add 'adehabitat 1.8.18' after 'adehabitatHS' for predict function used later.
library(maptools)
library(rgdal)
library(RSAGA)
library(spatstat)
library(splancs)

setwd("/Users/vickycul/Documents/PhD/CamptolomaProject/Submission_2019-09-11/0-Appendix/UpdatedCode_Hengl2009")
source("rsaga_functions_vmvc.R")

dataName <- "dataName"
dataName_pastTime <- "dataName_pastTime"
ascFolder <- paste0("ascFolder/")
saveName <- paste0("model_", dataName)

## [ load data.frame called "dataLandscape" from a RData file (here I used a RData file as my data.frame was very large and saving it as a .txt file took a very long time) ] dataLandscape = [x,y, present (0,1), variable1, v2, v3.....]
load(paste0(dataName,".RData")) # = dataLandscape

  
#-------------------------------
# 1. Data Organisation and Folder Creation
#-------------------------------
# Here I save various files (e.g. grid file) because these files take a long time to create if you have large data sets. That way you can simply upload them if you wish to run or modify the model and reduce computing time. If you are unsure, then create these files each time.
# I also create folders to save the results (data sets and figures)
if(!file.exists(saveName)) dir.create(file.path(saveName))
if(!file.exists(paste0(saveName,"/bei"))) dir.create(file.path(paste0(saveName,"/bei")))
if(!file.exists("grids")) dir.create(file.path("grids"))
if(!file.exists(ascFolder)) dir.create(file.path(ascFolder))
if(!file.exists("templist")) dir.create(file.path("templist"))
  
if(!file.exists(paste0("grids/grids",saveName,".RData"))){
  data.temp <- na.omit(dataLandscape)
  grids <- as(SpatialPixelsDataFrame(points =data.temp[c("x", "y")], data = data.temp[-c(1,2)]), "SpatialGridDataFrame")
  rm(data.temp)
  save(file=paste0("grids/grids",saveName,".RData"), list=c("grids"))} else load(paste0("grids/grids",saveName,".RData"))
      
## Create bei.pnt SpatialPointsDataFrame of the locations (i.e. Present = 1).
bei <- subset(data, subset=data$Present10 != 0)
bei <- bei[!duplicated(bei[1:2]), ]
  
bei.pnt <- data.frame(x=bei$x, y=bei$y, no=rep(1, length(bei$x)))
coordinates(bei.pnt) <- ~x+y
writeOGR(bei.pnt, paste0(saveName,"/bei"), "bei", "ESRI Shapefile", overwrite_layer = T)
    
## Create bei.ppp which is bei in class ppp.
r           <- raster(grids[1:3])
r[is.na(r)] <- -10000
make.mask   <- as.matrix(rasterToPoints(r))
mask        <- rotate_vmvc(rotate_vmvc(rotate_vmvc(t(matrix(make.mask[,3]!=-10000,  nrow=nrow(r), ncol=ncol(r), byrow=T)))))
window      <- owin(xrange=c(xmin(r),xmax(r)), yrange=c(ymin(r),ymax(r)), mask= mask)
    
## reformat the point pattern so it fits the grids:
bei.ppp <- ppp(bei$x, bei$y, window)
bei.ppp <- as.ppp(bei.ppp)
save(file=paste0(saveName,"/bei/beippp.RData"), list="bei.ppp")

  
#-------------------------------
# 2. Kernel density estimation
#-------------------------------
dist.bei <- nndist(coordinates(grids)[,1],coordinates(grids)[,2])
dist.box <- boxplot(dist.bei, plot=F)
    
## compare with the inspection density for this scale:
bei.pixsize <- sqrt(areaSpatialGrid(grids)/length(bei$x))

## optimal selection of the bandwidth size using Berman and Diggle (1989):
gridbbox <- as.points(list(x=c(grids@bbox[1,1],grids@bbox[1,2],grids@bbox[1,2],grids@bbox[1,1]), y=c(grids@bbox[2,1],grids@bbox[2,1],grids@bbox[2,2],grids@bbox[2,2])))
mserw    <- mse2d(pts = as.points(coordinates(bei.pnt)), poly = gridbbox, nsmse = 100, range = 10*bei.pixsize)
bw       <- mserw$h[which.min(mserw$mse)]
  
## We next derive a relative kernel intensity map
bandwidthSize<- min(c(bei.pixsize, dist.box$stats[5], bw)[c(bei.pixsize, dist.box$stats[5], bw)>=bei.pixsize])
bei.dens     <- density(bei.ppp, sigma=2*bandwidthSize)

DENS  <- grids$dens   <- as(bei.dens, "SpatialGridDataFrame")$v
DENSR <- grids$densr  <- grids$dens/(max(grids$dens, na.rm=T))
save(file=paste0(saveName,"/gridsDENS_DENSR",saveName,".RData"), list=c("DENS", "DENSR"))
save(file=paste0(saveName,"/grids",saveName,".RData"), list=c("grids"))
    
bei.pnt.plot <- list("sp.points", bei.pnt, pch="+", cex=.7, col="red")
plt.dens1    <- spplot(grids["densr"], scales=list(draw=F), at=seq(0,1,0.025), col.regions=grey(rev(seq(0,1,0.025))), sp.layout=bei.pnt.plot, main="Relative Kernal Intensity Map")
jpeg(file=paste0(saveName,"/DensityR_", saveName,".jpg"), width=1000, height=1000, bg="white", quality=100)
  print(plt.dens1)
dev.off()
  
#-------------------------------
# 3. Habitat Suitability Analysis
#-------------------------------
## HSA in adehabitat:
if(!file.exists(paste0("templist/templist",saveName,".RData"))){
  for(i in 1:length(names(data)[-c(1:3)]))
    if(!file.exists(paste0(ascFolder,names(data)[(i+3)],".asc")))
      writeRaster(rasterFromXYZ(data[c(1,2,(i+3))]), paste0(ascFolder,names(data)[(i+3)],".asc"),format="ascii",overwrite=TRUE)
  
  for(i in 0:length(names(data)[-c(1:3)]))
    if(i==0) templist <- list() else templist[[i]] <- import.asc(paste0(ascFolder,names(data)[(i+3)],".asc"))
    names(templist) <- names(data)[-c(1:3)]
    save(file=paste0("templist/templist",saveName,".RData"), list=c("templist"))
} else load(paste0("templist/templist",saveName,".RData"))

if(!file.exists(paste0(paste0(saveName),"/beidata.RData"))){
  beidata <- data2enfa(as.kasc(templist), bei.pnt@coords)
  save(file=paste0(paste0(saveName),"/beidata.RData"), list=c("beidata"))} else load(paste0(saveName,"/beidata.RData"))
rm(templist)
(enfa.bei <- tryCatch(madifa(dudi.pca(beidata$tab, scannf=FALSE), beidata$pr, scannf=FALSE, nf=2), error=function(e) e)) # Sometimes the matix is singular in madifa, enfa usually works in this case.
if(inherits(enfa.bei, "error")) enfa.bei <- enfa(dudi.pca(beidata$tab, scannf=FALSE), beidata$pr, scannf=FALSE, nf=2)

bei.dist       <- predict(enfa.bei, beidata$index, beidata$attr) # package(adehabitat)
attr(bei.dist, "type") <- "numeric"                              # !!!! For some reason this is needed to be done sometimes because type is 'factor'. No idea why.
grids$bei.dist <- as.SpatialGridDataFrame.im(asc2im(bei.dist))$v
sum.dist       <- summary(grids$bei.dist)
grids$rankv    <- rank(grids$bei.dist, ties.method="first")
grids$hsit     <- ifelse(grids$bei.dist<sum.dist[["Median"]], (1-grids$rankv/max(grids$rankv))*100, (1-grids$rankv/max(grids$rankv))*100)
grids$hsi      <- 100*round((grids$hsit-min(grids$hsit, na.rm=T))/(max(grids$hsit, na.rm=T)-min(grids$hsit, na.rm=T)), 3)

plt.HSI        <- spplot(grids["hsi"], at=seq(0,100,2.5), col.regions=grey(rev(seq(0,1,0.025))), main="Habitat Suitability Index (0-100%)", sp.layout=list("sp.points", pch="+", col=3, bei.pnt))
jpeg(file=paste0(saveName,"/HSI_madifa_TrendModel_density-bw",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100)
  print(plt.HSI)
dev.off()

plt.HSI        <- spplot(grids["hsi"], at=seq(0,100,2.5), col.regions=bpy.colors(), main="ALL Habitat Suitability Index (0-100%)", sp.layout=list("sp.points", pch="+", col=3, bei.pnt))
jpeg(file=paste0(saveName,"/HSI_madifa_TrendModel_density-colour",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100)
  print(plt.HSI)
dev.off()

save(file=paste0(saveName,"/grids",saveName,".RData"), list=c("grids"))
HSI.madifa <- as.data.frame(grids)[c("x","y","hsi")]
save(file=paste0(paste0(saveName),"/HSI-madifa.RData"), list=c("HSI.madifa"))
# write.table(as.data.frame(grids)[c("x","y","hsi")], paste0(saveName,"/HSI-madifa.txt"), quote = FALSE)

#-------------------------------
# 4. Create Pseudo Absences
#-------------------------------
## https://sourceforge.net/p/saga-gis/discussion/790705/thread/e286dc89/
## first the buffer distance:
rsaga.geoprocessor_vmvc(env=env, lib="grid_gridding", module=0,
                        display.command = F, invisible = T,
                        param=list(GRID=paste0(saveName,"/bei/bei_buffer.sgrd"), INPUT=paste0(saveName,"/bei/bei.shp"), FIELD=0, LINE_TYPE=0, TARGET_USER_SIZE=grids@grid@cellsize[[1]],
                                   TARGET_USER_XMIN=grids@bbox[1,1]+grids@grid@cellsize[[1]]/2, TARGET_USER_XMAX=grids@bbox[1,2]-grids@grid@cellsize[[1]]/2, TARGET_USER_YMIN=grids@bbox[2,1]+grids@grid@cellsize[[1]]/2, TARGET_USER_YMAX=grids@bbox[2,2]-grids@grid@cellsize[[1]]/2))

## now extract a buffer distance map and load it back to R:
## the parameters DIST (float=500.000000) and IVAL (integer=100) are estimated based on the grid properties:
rsaga.geoprocessor_vmvc(env=env, lib="grid_tools", module=10, param=list(SOURCE=paste0(saveName,"/bei/bei_buffer.sgrd"), DISTANCE=paste0(saveName,"/bei/bei_buffer.sgrd"), ALLOC=paste0(saveName,"/bei/bei_buffer.sgrd"), BUFFER=paste0(saveName,"/bei/bei_buffer.sgrd"), DIST=sqrt(areaSpatialGrid(grids))/3))#round(grids@grid@cellsize[[1]])))
rsaga.sgrd.to.esri_vmvc(env=env, in.sgrds=paste0(saveName,"/bei/bei_buffer.sgrd"), out.grids=paste0(saveName,"/bei/bei_dist.asc"), out.path=getwd(), prec=1)

a<-readGDAL(paste0(saveName,"/bei/bei_dist.asc"))
save(file=paste0(saveName,"/bei/bei_dist.RData"),list=c("a"))

load(file=paste0(saveName,"/bei/bei_dist.RData"))
if(dim(a)[1]==length(grids["hsi"])){
  grids$buffer <- a$band1
} else {
  Map   <- SpatialPixelsDataFrame(points = as.data.frame(a)[c("x", "y")], data = as.data.frame(a)["band1"])
  Coord <- SpatialPoints(as.data.frame(coordinates(grids)))
  grids$buffer <- join_vmvc(xy = Coord, x = Map)
}

grids$bufferr <- grids$buffer/max(grids$buffer, na.rm=T)
grids$weight  <- ((100*grids$bufferr+(100-grids$hsi))/2)^2
# writeGDAL(grids["weight"], paste0(saveName,"/weight_sub.mpr"), "ILWIS")
dens.weight   <- as.im(as.image.SpatialGridDataFrame(grids["weight"]))

bei.absences <- rpoint(length(bei.pnt$no), f=dens.weight)
bei.absences <- data.frame(x=bei.absences$x, y=bei.absences$y ,no=rep(0, length(bei.pnt$no)))
coordinates(bei.absences) <- ~x+y

## combine the occurences and absences:
bei.all <- rbind(bei.pnt["no"], bei.absences["no"])
save(file=paste0(saveName,"/Pseudo-AbsAndPres.RData"), list="bei.all")

plot.temp <- spplot(bei.all["no"], col.regions=rainbow(2), cex=1.2, main="Absences and Presences")
jpeg(file=paste0(saveName,"/Pseudo-AbsAndPres",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100) # !!!!
  print(plot.temp)
dev.off()

save(file=paste0(saveName,"/grids",saveName,".RData"), list=c("grids"))

formulaNames <- names(data)[-c(1:3)]

load(file=paste0(saveName,"/Pseudo-AbsAndPres.RData"))
load(file=paste0(saveName,"/grids",saveName,".RData"))

#-------------------------------
# 5. Regression-kriging
#-------------------------------
# Next, we can overlay the predictors and the estimated intensities 
# at occurrence and absence locations: 
bei.ov2      <- over(bei.all, grids)                                # !!!! Used grids here instead of pc.comps
bei.ov2$no   <- bei.all$no
temp.bei.ov2 <- na.omit(cbind(coordinates(bei.all[-1]), bei.ov2))   # remove any Na s
if(dim(temp.bei.ov2)[1]==0)temp.bei.ov2 <- cbind(coordinates(bei.all[-1]), bei.ov2)

bei.ov2_SpPD <- SpatialPointsDataFrame(temp.bei.ov2[1:2],data = temp.bei.ov2[-c(1:2)])

# regression analysis:
# Convert the original values to logits:
bei.ov2_SpPD$log.densr <- log((bei.ov2_SpPD$densr+0.001)/(1-(bei.ov2_SpPD$densr-0.001)))

# =====
# lm !!!! Here is where the lm model is made.
myFormula.lm    <- formula(c("log.densr ~", paste(formulaNames[-length(formulaNames)], "+"),formulaNames[length(formulaNames)]))
summary(lm2.bei <- lm(log.densr~hsi, data=bei.ov2_SpPD))
summary(lm3.bei <- lm(myFormula.lm, data=bei.ov2_SpPD))

(bei.lm3.step     <- tryCatch(step(lm3.bei), error=function(e) e))  # if the step function fails, then use the original lm.
if(inherits(bei.lm3.step, "error")) bei.lm3.step <- lm3.bei
if(length(names(bei.lm3.step$coefficients))==1) bei.lm3.step <- lm3.bei

fitnull.lm3     <- lm(log.densr~1, data=bei.ov2_SpPD)
AIC(fitnull.lm3)  # Check the fit to the null model.
AIC(bei.lm3.step)

# =====
# GLM with logit link function: !!!! Here is where the glm model is made
myFormula.glm   <- formula(c("no ~", paste(formulaNames[-length(formulaNames)], "+"),formulaNames[length(formulaNames)]))

glm.bei <- glm(myFormula.glm, data=bei.ov2_SpPD, binomial()) #!!!! binomial
titleGLM <- "Binomial GLM residuals"

# If the binomial distribution fails (warning returned is "glm.fit: fitted probabilities numerically 0 or 1 occurred"  or "glm.fit: algorithm did not converge"), use a normal distribution.
# glm.bei <- glm(myFormula.glm, data=bei.ov2_SpPD)
# titleGLM <- "Normal GLM residuals"

bei.glm.step   <- glm.bei
(bei.glm.step   <- step(glm.bei))   # if the step function fails, then use the original glm.
  if(length(names(bei.glm.step$coefficients))==1)
    if(names(bei.glm.step$coefficients)=="(Intercept)")
      bei.glm.step$coefficients <- glm.bei$coefficients

fitnull.glm <- glm(no ~ 1, data=bei.ov2_SpPD)
AIC(fitnull.glm )   # Check the fit to the null model.
AIC(bei.glm.step)

# =====
# Fig: Varigram plots next to each other:
res.var <- variogram(residuals(bei.lm3.step)~1, bei.ov2_SpPD)
res.vgm <- fit.variogram(res.var, vgm(nugget=0, model="Exp", range=sqrt(areaSpatialGrid(grids))/3, psill=var(residuals(bei.lm3.step), na.rm=T)))
plot.variogram <- plot(res.var, res.vgm, plot.nu=T, pch="+", main="Intensity residuals")

jpeg(file=paste0(saveName,"/variogram_bei_",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100) # !!!!
  print(plot.variogram)
dev.off()

bei.glm.step$residual <- bei.glm.step$model$no - glm.bei$fitted.values
hist(bei.glm.step$residual, breaks=30)
res.bin  <- variogram(bei.glm.step$residual~1, bei.ov2_SpPD)
res.bvgm <- fit.variogram(res.bin, vgm(nugget=0, model="Exp", range=sqrt(areaSpatialGrid(grids))/3, psill=var(bei.glm.step$residual, na.rm=T)))  # !!!! glm.bei -> bei.glm.step
plot.variogramGLM <- plot(res.bin, res.bvgm, plot.nu=T, pch="+", main=titleGLM)
jpeg(file=paste0(saveName,"/variogram_bei-GLM_",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100) # !!!!
  print(plot.variogramGLM)
dev.off()

#-------------------------------
## 6. Final predictions
#-------------------------------
## regression part:
## regression-kriging:
## !!!! Need to use the results of the step function of the lm (lm because we are using lm for vt.gr)
## !!!! This is to stop singularity of the model when predicting.
myFormula.gstat <- if(length(names(bei.lm3.step$coefficients))==2) formula(c("densr ~",paste(names(bei.lm3.step$coefficients)[2]))) else formula(c("densr ~",paste(names(bei.lm3.step$coefficients)[2:(length(names(bei.lm3.step$coefficients))-1)],"+"),names(bei.lm3.step$coefficients)[length(names(bei.lm3.step$coefficients))]))

vt.gt <- gstat(id=c("dens"), formula=myFormula.gstat, data=bei.ov2_SpPD)
vt.gr <- gstat(id=c("dens"), formula=residuals(lm3.bei)~1, data=bei.ov2_SpPD, model=res.vgm)

vt.reg <- predict(vt.gt, grids) # !!!! This is where I need to add the new data to predict backwards (replace "grids" with the new data).
# hist(vt.reg$dens.pred)
# spplot(vt.reg[1], col.regions=grey(rev(seq(0,1,0.025)))) # at=seq(-4,1,0.25),

vt.ok       <- predict(vt.gr, grids, nmax=80, beta=1, BLUE=FALSE, debug.level=-1) # !!!! This is where I need to add the new data to predict backwards (replace "grids" with the new data).
vt.reg$dens <- exp(vt.reg$dens.pred+vt.ok$dens.pred)/(1+exp(vt.reg$dens.pred+vt.ok$dens.pred))
vt.reg$densA<- vt.reg$dens * length(bei.pnt$no)/sum(vt.reg$dens, na.rm=T)
# sum(vt.reg$densA, na.rm=T) ==  length(bei.pnt) # check if the sum of counts equals the population!
vt.reg$dens.sumvar <- vt.reg$dens.var+vt.ok$dens.var
  
Pres <- SpatialPoints( as.data.frame(bei.ov2_SpPD)[c("x","y")][bei.ov2_SpPD$no==TRUE,][c("x", "y")])
Abs  <- SpatialPoints( as.data.frame(bei.ov2_SpPD)[c("x","y")][bei.ov2_SpPD$no==FALSE,][c("x", "y")])
plot.e <- spplot(vt.reg["densA"], at=seq(0,max(vt.reg$densA, na.rm = T),max(vt.reg$densA, na.rm = T)/30), col.regions=grey(rev(seq(0,1,0.025))), sp.layout=list(list("sp.points", pch="+", col=3, Pres),list("sp.points", pch="+", col=2, Abs)))
jpeg(file=paste0(saveName,"/e-FinalPredRegressionKrigingOverAllIntensity_",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100) # !!!!
  print(plot.e)
dev.off()
  
vt.reg.densA <- as.data.frame(vt.reg)[c("x","y","densA")]
save(file=paste0(saveName,"/e-FinalPredRegressionKrigingOverAllIntensity_",saveName,".RData"), list="vt.reg.densA")
  
## GLM:
bin.reg <- predict(object = bei.glm.step , newdata=grids, type="response", se.fit=T) # !!!! This is where I need to add the new data to predict backwards  (replace "grids" with the new data).
bin.gr  <- gstat(id=c("no"), formula=bei.glm.step$residual~1, data=bei.ov2_SpPD, model=res.bvgm)
bin.ok  <- predict(object = bin.gr, newdata=grids, nmax=80, beta=1, BLUE=FALSE, debug.level=-1)  # !!!! This is where I need to add the new data to predict backwards.
  
# temp <- as(SpatialPixelsDataFrame(points = as.data.frame(grids)[c("x", "y")], data = as.data.frame(bin.reg$fit)), "SpatialGridDataFrame")
temp <- SpatialPixelsDataFrame(points = as.data.frame(grids)[c("x", "y")], data = as.data.frame(bin.reg$fit))

bin.ok$rk.bin  <- temp$`bin.reg$fit` + bin.ok$no.pred # In temp$`bin.reg$fit` + bin.ok$no.pred : longer object length is not a multiple of shorter object length
bin.ok$rk.binf <- ifelse(bin.ok$rk.bin<0, 0, ifelse(bin.ok$rk.bin>1, 1, bin.ok$rk.bin))

Pres <- SpatialPoints( as.data.frame(bei.ov2_SpPD)[c("x","y")][bei.ov2_SpPD$no==TRUE,][c("x", "y")])
Abs  <- SpatialPoints( as.data.frame(bei.ov2_SpPD)[c("x","y")][bei.ov2_SpPD$no==FALSE,][c("x", "y")])
plot.f <- spplot(bin.ok["rk.binf"], col.regions=grey(rev(seq(0,1,0.025))), sp.layout=list(list("sp.points", pch="+", col=3, Pres),list("sp.points", pch="+", col=2, Abs)))
jpeg(file=paste0(saveName,"/f-FinalPredRegressionGLM_",saveName,".jpg"), width=1000, height=1000, bg="white", quality=100) # !!!!
  print(plot.f)
dev.off()

FinalPredRegGLM <- as.data.frame(bin.ok)[c("x","y","rk.binf")]
save(file=paste0(saveName,"/f-FinalPredRegressionGLM_",saveName,".RData"), list="FinalPredRegGLM")
write.table(FinalPredRegGLM, paste0(saveName,"/f-FinalPredRegressionGLM_",saveName,".txt"), quote = FALSE,row.names = F)


#-------------------------------
# 7. Projecting the Model Over New Data / projecting back in time.
#-------------------------------

load(paste0(dataName_pastTime,".RData")) # = dataLandscape_pastTime for the past. It is in the same format as data.frame dataLandscape
if(!file.exists(paste0(saveName,"/Projections/"))) dir.create(paste0(saveName,"/Projections/"))

newdata <- SpatialPixelsDataFrame(as.data.frame(dataLandscape_pastTime)[c("x","y")],as.data.frame(dataLandscape_pastTime))

vt.reg      <- predict(vt.gt, newdata) # !!!! This is where I add the new data to predict backwards.
vt.ok       <- predict(vt.gr, newdata, nmax=80, beta=1, BLUE=FALSE, debug.level=-1) # !!!! This is where add the new data to predict backwards.
vt.reg$dens <- exp(vt.reg$dens.pred+vt.ok$dens.pred)/(1+exp(vt.reg$dens.pred+vt.ok$dens.pred))
vt.reg$densA<- vt.reg$dens * length(bei.pnt$no)/sum(vt.reg$dens, na.rm=T)
vt.reg$dens.sumvar <- vt.reg$dens.var+vt.ok$dens.var 

e <- spplot(vt.reg["densA"], at=seq(0,max(vt.reg$densA, na.rm = T), max(vt.reg$densA, na.rm = T)/30), main=dataName_pastTime, col.regions=grey(rev(seq(0,1,0.025))))
jpeg(file=paste0(saveName,"/Projections/e-FinalPredRegressionKrigingOverAllIntensity_",saveName, "-", dataName_pastTime,".jpg"), width=1000, height=1000, bg="white", quality=100)
  print(e)
dev.off()

# writeGDAL(vt.reg["densA"], paste0(saveName,"/Projections/","e-FinalPredRegressionKrigingOverAllIntensity_",timeNames,".mpr"), "ILWIS")
# writeGDAL(vt.reg["dens.sumvar"], "rk_densvar.mpr", "ILWIS")
write.table(as.data.frame(vt.reg)[c("x","y","densA")],paste0(saveName,"/Projections/e-FinalPredRegressionKrigingOverAllIntensity_",saveName, "-", dataName_pastTime,".txt"), quote = FALSE, row.names = F)

## binomial GLM:
bin.reg <- predict(object = bei.glm.step , newdata, type="response", se.fit=T) # !!!! This is where I need to add the new data to predict backwards.
bin.gr  <- gstat(id=c("no"), formula=bei.glm.step$residual~1, data=bei.ov2_SpPD, model=res.bvgm)
bin.ok  <- predict(object = bin.gr, newdata, nmax=80, beta=1, BLUE=FALSE, debug.level=-1)  # !!!! This is where I need to add the new data to predict backwards.

temp <- SpatialPixelsDataFrame(points = as.data.frame(newdata)[c("x", "y")], data = as.data.frame(bin.reg$fit))

bin.ok$rk.bin  <- temp$`bin.reg$fit` + bin.ok$no.pred
bin.ok$rk.binf <- ifelse(bin.ok$rk.bin<0, 0, ifelse(bin.ok$rk.bin>1, 1, bin.ok$rk.bin))

f <- image(bin.ok["rk.binf"], col=grey(rev(seq(0,1,0.025))))
jpeg(file=paste0(saveName,"/Projections/f-FinalPredRegressionGLM_",saveName, "-", dataName_pastTime,".jpg"), width=1000, height=1000, bg="white", quality=100)
  image(bin.ok["rk.binf"], col=grey(rev(seq(0,1,0.025))))
dev.off()

# writeGDAL(bin.ok["rk.binf"], paste0(saveName,"/Projections/f-FinalPredRegressionbinGLM_",timeNames,".mpr"), "ILWIS")
write.table(as.data.frame(bin.ok)[c("x","y","rk.binf")],paste0(saveName,"/Projections/f-FinalPredRegressionGLM_",saveName, "-", dataName_pastTime,".txt"), quote = FALSE, row.names = F)

# =======================
# =======================
### END.
##
#